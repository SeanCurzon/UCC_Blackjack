import random
from dealer import Dealer
from deck import Deck
from card import Card
from player import Player
from hand import Hand

def main():

    dealer = Dealer()
    player1 = Player(dealer)
    player2 = Player(dealer)
    player3 = Player(dealer)
    player4 = Player(dealer)

    playerlst = [player1,player2,player3,player4]

    for item in playerlst :
        item.startingHand(dealer)

    player4.compareHandAgainstDealer(dealer, player4._mainlst)
    
if __name__ == "__main__":
    main()
    
