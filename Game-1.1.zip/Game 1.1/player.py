import random
from hand import Hand


class Player():
    
    _id = 1
    playersList = []
    mainlst = {}
    
    def __init__(self, dealer):

        self._id = Player._id
        Player._id += 1
        (self._balance) = 1000
        self._hand = Hand(self._id)
        self._handValue = self._hand._handValue
        self._deck = dealer._deck
        self._playersList = Player.playersList
        self._playersList += [self._id]
        self._mainlst = Player.mainlst
        self._handlst = []
        

    def main_hit(self,dealer, player_id):
        main_boolean = True
        # deal until hand has 2 cards
        if len(self._hand) < 2:
            self.hit()
            print ( "Total Hand Value: %i\n" % (self._handValue))
        elif len(self._hand) == 2:
            if self._handlst[0]._cardValue == self._handlst[1]._cardValue:
                spl = input("Do you want to split? y/n: ")
                if spl == 'y':
                    self.split(dealer, self._id)
                elif spl == 'n':
                    self.check_hand(dealer, player_id, main_boolean)
            else:
                self.check_hand(dealer, player_id, main_boolean)
        else:
            self.check_hand(dealer, player_id, main_boolean)
            

    def split_hit(self,dealer, player_id):
        main_boolean = False
        # deal until hand has 2 cards
        if len(self._hand) < 2:
            self.hit()
            print ( "Total Hand Value: %i\n" % (self._handValue))
        else:
            # busts when total hand value is greater than 21
            self.check_hand(dealer, player_id, main_boolean)

    def check_hand(self, dealer, player_id, main_boolean):
        if self._handValue > 21:
            print("BUST")
            self.bust(player_id, self._handValue)
        else:
            hitorstay = input("Do you want to Hit or Stay? Hit/Stay ")
            if hitorstay == "h":
                self.hit()
                if self._handValue > 21 :
                        for item in self._handlst :
                            if item._name[0] == "A" :
                                item._cardValue = 1
                                self.countPlayerHand()
                print ( "Total Hand Value: %i\n" % (self._handValue))
                if main_boolean == True:
                    self.main_hit( dealer, player_id)
                else:
                    self.split_hit( dealer, player_id)
            elif hitorstay == "s":
                    self.stay(dealer, player_id, self._handValue)

    def split( self, dealer, player_id ) :
        temp = self._hand._hand[1]
        self._hand.remove(temp)
        self._handlst.remove(temp)
        print(self._handlst)
        self._handValue -= temp._cardValue
        #Hand 1
        print("Hand 1: ", self._hand)
        print("Hand 1 value: ", self._handValue)
        i = 0
        while i < 2:
            i += 1
            self.split_hit(dealer, player_id)
        #self.main_hit(dealer, player_id)
        score = self._handValue
        print("Score: ", score)
        if score > 21:
            self._balance -= self._bet
        elif dealer._handValue > 21:
            self._balacne += self._bet
        elif score < dealer._handValue:
            self._balance -= self._bet
        elif score > dealer._handValue:
            self._balance += self._bet

        print(self._balance)
        

        #for item in self._handlst:
            #print(item)

        self._handlst = []
        self._hand.empty()
        self._handValue = 0
        self._hand.add(temp)
        self._handlst += [temp]
        self._handValue += temp._cardValue
        #Hand 2
        print("Hand 2: ", self._hand)
        print("Hand 2 value: ", self._handValue)
        i = 0
        while i < 2:
            i += 1
            self.split_hit(dealer, player_id)
        #self.main_hit(dealer, player_id)
        score1 = self._handValue
        print("Score: ",score1)


    def startingHand(self, dealer):
        self.bet(self._id)
        i = 0
        while i < 2:
            i += 1
            Hand(self._id)
            self.main_hit(dealer, self._id)
        self.main_hit(dealer, self._id)  

    def bet(self, player_id):
        self._bet = int(input("How much would player %s like to bet? " %player_id))


    def hit(self):
        temp = self._deck[0]
        new_card = temp
        if new_card._name[0] == "A" :
            if self._handValue >= 11 :
                new_card._cardValue = 1
        self._deck.remove(self._deck[0])
        self._deck.append(temp)
        self._hand.add(new_card)
        self._handlst += [new_card]
        print(new_card)
        self._handValue += new_card._cardValue

    def countPlayerHand(self) :

        self._handValue = 0

        for item in self._handlst :
            self._handValue += item._cardValue
        return self._handValue




    def bust(self, player_id, hand_value):
        self._mainlst[player_id] = [hand_value, self._bet, self._balance]
        print("Player %s went bust \n" % (player_id))

    def stay(self, dealer, player_id, hand_value):
        self._mainlst[player_id] = [hand_value, self._bet, self._balance]
        print(self._mainlst)
        print("Player %s stayed on Value = %i \n" % (player_id, hand_value))

    def compareHandAgainstDealer(self, dealer, mainlst) :

        print ( "Dealer Hand: %s" % ( dealer._hand))
        print ( "Dealer Score: %i\n" % (dealer._handValue))

        for item in mainlst :
            if mainlst[item][0] > 21 :
                print ( "Player %i went Bust. Score: %i" % ( item, mainlst[item][0] ))
                mainlst[item][2] -= mainlst[item][1]
                print ( "Player %i Balance: %i \n" % ( item, mainlst[item][2]))
            elif dealer._handValue > 21 :
                print ("Dealer Bust")
                print ("You win")
                (mainlst[item][2]) += (mainlst[item][1])
                print("Player %i Balance: %i\n" % (item,mainlst[item][2]))
            elif mainlst[item][0] > dealer._handValue :
                print ( "Player %i Score: %i" % (item,mainlst[item][0]))
                print ( "You win\n" )
                (mainlst[item][2]) += (mainlst[item][1])
                print("Player %i Balance: %i\n" % (item,mainlst[item][2]))
            elif mainlst[item][0] == dealer._handValue :
                print ( "Draw, your bet has been refunded")
                print("Player %i Balance: %i\n" % (item,mainlst[item][2]))
            else :
                print ( "Player %i Score: %i" % (item, mainlst[item][0]))
                print ("You Lose")
                mainlst[item][2] -= mainlst[item][1]
                print("Player %i Balance: %i\n" % (item, mainlst[item][2]))
