import random

class Hand():
    def __init__(self, playerId):
        self._ID = playerId
        self._hand = []
        self._handValue = 0

    def add(self, card):
        self._hand.append(card)

    def __len__(self):
        return len(self._hand)

    def empty(self):
        self._hand = []

    def remove(self, card ) :

        self._hand.remove(card)
        
    def __str__(self):

        s = ""
        for item in self._hand :
            s += str(item)
            s += ", "
        return s
