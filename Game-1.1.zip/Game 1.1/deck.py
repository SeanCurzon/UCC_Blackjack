import random
from card import Card


class Deck():
    def __init__(self):

        """'A','2','3','4','5','6','7','8','9','10','J','Q','K'"""

        self._deck = []
        self._faces = ['4','5','6']
        self._suits = ['Diamonds','Clubs','Hearts','Spades']

    def createDeck(self, numDecks):
        i = 0
        while i < numDecks:
            i += 1
            for f in range(len(self._faces)):
                for s in range(len(self._suits)):
                    self._deck.append(Card(self._faces[f] + "of" + self._suits[s], self._faces[f],self._suits[s]))              
        return self._deck
	
	
    def shuffleDeck(self):
        random.shuffle(self._deck)
            
    def __str__(self):
        return str(self._deck)
