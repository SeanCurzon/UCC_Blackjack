import random


class Card():

    def __init__(self, name_of_card, face, suit):
        self._name = name_of_card
        self._face = face
        self._suit = suit
        if self._face == "A":
            self._cardValue = 11
        elif self._face == "J":
            self._cardValue = 10
        elif self._face == "Q":
            self._cardValue = 10
        elif self._face == "K":
            self._cardValue = 10
        elif self._face == "10":
            self._cardValue = 10
        else:
            self._cardValue = int(self._name[0])


    def __str__(self):
        
        return str(self._name)

