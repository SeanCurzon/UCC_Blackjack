import random

class Hand():
    """Creates a hand object"""
    def __init__(self, playerId):
        """initialised with a player id,hand value and a list called hand"""
        self._ID = playerId
        self._hand = []
        self._handValue = 0

    def add(self, card):
        """Adds a card object to the hand"""
        self._hand.append(card)

    def __len__(self):
        """returns the number of cards in the hand"""
        return len(self._hand)

    def empty(self):
        """empties all the cards out of the hand"""
        self._hand = []

    def remove(self, card ) :
        """removes a card object from the hand"""
        self._hand.remove(card)
        
    def __str__(self):
        s = ""
        for item in self._hand :
            s += str(item)
            s += ", "
        return s
