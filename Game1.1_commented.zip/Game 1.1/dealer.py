import random
from deck import Deck
from deck import Deck
from card import Card
from player import Player
from hand import Hand


class Dealer:
    """Creates a Dealer object initialized with the following attributes"""
    def __init__(self):
        deck = Deck()
        self._id = "dealer"
        self._deck = deck.createDeck(1)
        random.shuffle(self._deck)
        self._hand = Hand(self._id)
        self._handValue = self._hand._handValue
        self._handlst = []
        dealerHand1 = self.dealerHand()

    def dealerHand(self) :
        """This function keeps hitting the dealers hand until the hand goes bust
           or gets a value of 17 or more"""
        V = False
        while V != True :
            temp = self._deck[0]
            new_card = temp
            if len( self._hand) == 0 :
                print("Dealer 1st Card: %s \n" % (new_card))
            if new_card._name[0] == "A" :
                if self._handValue >= 11 :
                    new_card._cardValue = 1
            self._deck.remove(self._deck[0])
            self._deck.append(temp)
            self._hand.add(new_card)
            self._handlst += [new_card]
            self._handValue += new_card._cardValue
            if self._handValue > 21 :
                for item in self._handlst :
                    if item._name[0] == "A" :
                        item._cardValue = 1
                        self.countDealerHand()
            if self._handValue >= 17 :
                V = True
            	
    def getNewCard(self):
        """Pulls the card off the top of the deck"""
        return self._deck[0]

    def countDealerHand(self) :
        """add all the card values together to get the handvalue"""
        self._handValue = 0

        for item in self._handlst :
            self._handValue += item._cardValue
        return self._handValue

